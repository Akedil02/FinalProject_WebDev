import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tour-details',
  templateUrl: './tour-details.component.html'
})
export class TourDetailsComponent implements OnInit {
  tourId!: string;
  tour: any;

  mockTours = [
    { id: '1', name: 'Alpine Adventure', description: 'Exciting tour in the Alps.', price: 499 },
    { id: '2', name: 'Beach Escape', description: 'Relaxing trip to the tropics.', price: 699 },
    { id: '3', name: 'Cultural Journey', description: 'Explore historic cities.', price: 599 }
  ];

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.tourId = this.route.snapshot.paramMap.get('id')!;
    this.tour = this.mockTours.find(t => t.id === this.tourId);
  }
}
